package com.dicoding.handchat.ui.dictionary

import androidx.lifecycle.ViewModel
import com.dicoding.handchat.datasource.DataDictionaryEntity
import com.dicoding.handchat.utils.DataDummy

class DictionaryViewModel: ViewModel() {
    fun getTvShow(): List<DataDictionaryEntity> = DataDummy.generateDummyDic()
}