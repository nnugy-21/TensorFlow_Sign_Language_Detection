package com.dicoding.handchat.ui.dictionary

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.dicoding.handchat.R
import com.dicoding.handchat.databinding.ActivityDictionaryBinding
import com.dicoding.handchat.datasource.DataDictionaryEntity

class DictionaryActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDictionaryBinding
    companion object {
        const val DETAIL_TV = "detail_tv"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
binding= ActivityDictionaryBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val viewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory())[DataDictionaryViewModel::class.java]
        val extras = intent.extras
        if (extras != null) {
            val movieId = extras.getString(DETAIL_TV)
            if (movieId != null) {
                viewModel.selectTv(movieId)
                checkTv(viewModel.getTvShow() as DataDictionaryEntity)
            }
        }
    }
    private fun checkTv(movieEntity: DataDictionaryEntity) {
        with(binding){
            titleKamus.text = movieEntity.nama
        }
        Glide.with(this)
                .load(movieEntity.tvimagePath)
                .apply(RequestOptions().override(3500, 2000))
                .into(binding.itemImgPhoto)
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return super.onSupportNavigateUp()
    }
}