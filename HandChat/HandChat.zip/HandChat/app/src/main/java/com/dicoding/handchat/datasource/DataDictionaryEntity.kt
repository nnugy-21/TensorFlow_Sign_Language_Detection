package com.dicoding.handchat.datasource

data class DataDictionaryEntity (
        var nama:String,
        var tvimagePath: Int,
)