package com.dicoding.handchat.ui.dictionary

import androidx.lifecycle.ViewModel
import com.dicoding.handchat.datasource.DataDictionaryEntity
import com.dicoding.handchat.utils.DataDummy

class DataDictionaryViewModel :ViewModel() {
    private lateinit var nama: String
    fun selectTv(tvId: String){
        this.nama = tvId
    }
    fun getTvShow(): DataDictionaryEntity {
        lateinit var tvShow: DataDictionaryEntity
        val tv = DataDummy.generateDummyDic()
        for (tvShowEntity in tv) {
            if (tvShowEntity.nama == nama) {
                tvShow = tvShowEntity
            }
        }
        return tvShow

    }
}