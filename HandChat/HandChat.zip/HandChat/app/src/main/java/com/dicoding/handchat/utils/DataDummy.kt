package com.dicoding.handchat.utils

import com.dicoding.handchat.R
import com.dicoding.handchat.datasource.DataDictionaryEntity

object DataDummy {

    fun generateDummyDic(): List<DataDictionaryEntity>{
        val kamus= ArrayList<DataDictionaryEntity>()

        kamus.add(
        DataDictionaryEntity(
            "A",
                R.drawable.aa
        )
        )
        return kamus
    }
}